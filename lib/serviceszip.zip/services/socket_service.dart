import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:google_maps_flutter/google_maps_flutter.dart';

class SocketService {
  static const String socketUrl = 'http://localhost:5000';
  static late io.Socket socket;
  static Function(LatLng, String)? onLocationUpdate;

  static void connectToSocket() {
    socket = io.io(
        socketUrl, io.OptionBuilder().setTransports(['websocket']).build());

    socket.onConnect((_) {
      print("🟢 Connected to WebSocket Server");
    });

    socket.on("busLocation", (data) {
      LatLng location = LatLng(data['latitude'], data['longitude']);
      String busId = data['busId'];

      if (onLocationUpdate != null) {
        onLocationUpdate!(location, busId);
      }
    });

    socket.onDisconnect((_) {
      print("🔴 Disconnected from WebSocket");
    });
  }
}
