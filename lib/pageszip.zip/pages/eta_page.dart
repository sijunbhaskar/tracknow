import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ETAPage extends StatefulWidget {
  const ETAPage({super.key});

  @override
  _ETAPageState createState() => _ETAPageState();
}

class _ETAPageState extends State<ETAPage> {
  String? _selectedBus;
  String? _selectedStop;
  String _etaResult = "";
  bool _isLoading = false;

  final List<Map<String, String>> _buses = [
    {"id": "1", "name": "Bus 101"},
    {"id": "2", "name": "Bus 202"},
  ];

  final List<Map<String, String>> _stops = [
    {"id": "1", "name": "Main Street Stop"},
    {"id": "2", "name": "City Center Stop"},
  ];

  Future<void> _fetchETA() async {
    if (_selectedBus == null || _selectedStop == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Select a bus and stop")));
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.get(Uri.parse(
          "http://192.168.43.198:5000/eta?busId=$_selectedBus&stopId=$_selectedStop"));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _etaResult =
              "ETA: ${data['eta']} minutes (Distance: ${data['distance']} km)";
        });
      } else {
        setState(() {
          _etaResult = "Failed to fetch ETA";
        });
      }
    } catch (e) {
      setState(() {
        _etaResult = "Error: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Estimated Time of Arrival (ETA)")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Select Bus:", style: TextStyle(fontSize: 18)),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(border: OutlineInputBorder()),
              value: _selectedBus,
              hint: const Text("Choose a bus"),
              items: _buses.map((bus) {
                return DropdownMenuItem<String>(
                  value: bus["id"],
                  child: Text(bus["name"]!),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedBus = value;
                });
              },
            ),
            const SizedBox(height: 20),
            const Text("Select Stop:", style: TextStyle(fontSize: 18)),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(border: OutlineInputBorder()),
              value: _selectedStop,
              hint: const Text("Choose a stop"),
              items: _stops.map((stop) {
                return DropdownMenuItem<String>(
                  value: stop["id"],
                  child: Text(stop["name"]!),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedStop = value;
                });
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchETA,
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Get ETA"),
            ),
            const SizedBox(height: 20),
            Text(
              _etaResult,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
