import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as io;

class AlertsPage extends StatefulWidget {
  const AlertsPage({super.key});

  @override
  _AlertsPageState createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage> {
  List<Map<String, dynamic>> _alerts = [];
  late io.Socket _socket;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchAlerts();
    _connectToSocket();
  }

  /// Fetch alerts from the API
  Future<void> _fetchAlerts() async {
    try {
      final response =
          await http.get(Uri.parse("http://192.168.43.198:5000/alerts"));
      if (response.statusCode == 200) {
        setState(() {
          _alerts = List<Map<String, dynamic>>.from(jsonDecode(response.body));
          _isLoading = false;
        });
      } else {
        _showError("Failed to load alerts");
      }
    } catch (e) {
      _showError("Error fetching alerts: $e");
    }
  }

  /// Connect to WebSocket for real-time alerts
  void _connectToSocket() {
    _socket = io.io("http://192.168.43.198:5000", <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false,
    });

    _socket.connect();
    _socket.on("newAlert", (data) {
      setState(() {
        _alerts.insert(0, Map<String, dynamic>.from(data));
      });

      // Show a SnackBar notification
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("New Alert: ${data['message']}")),
      );
    });
  }

  /// Show error message in Snackbar
  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _socket.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Alerts & Announcements")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _alerts.length,
              itemBuilder: (context, index) {
                final alert = _alerts[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    leading: Icon(
                      alert['type'] == 'delay'
                          ? Icons.timer
                          : alert['type'] == 'route_change'
                              ? Icons.alt_route
                              : Icons.warning,
                      color: alert['type'] == 'delay'
                          ? Colors.orange
                          : alert['type'] == 'route_change'
                              ? Colors.blue
                              : Colors.red,
                    ),
                    title: Text(alert['message']),
                    subtitle: Text("Type: ${alert['type'].toUpperCase()}"),
                  ),
                );
              },
            ),
    );
  }
}
