import 'login_page.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});

  @override
  _PassengerHomeState createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  GoogleMapController? _mapController;
  Map<String, Marker> _busMarkers = {};
  bool _isLoading = true; // Show loading indicator initially

  @override
  void initState() {
    super.initState();
    _fetchBusLocations();
    _connectToSocket();
  }

  /// Fetch all buses from API and add them to the map
  void _fetchBusLocations() async {
    try {
      List<Map<String, dynamic>> buses = await ApiService.getAllBuses();
      setState(() {
        for (var bus in buses) {
          _busMarkers[bus['busId']] = Marker(
            markerId: MarkerId(bus['busId']),
            position: bus['location'],
            infoWindow: InfoWindow(title: "Bus ${bus['busId']}"),
          );
        }
        _isLoading = false; // Hide loading indicator
      });
    } catch (e) {
      print("Error fetching bus locations: $e");
      setState(() {
        _isLoading = false;
      });
    }
  }

  /// Connects to WebSocket and updates buses in real time
  void _connectToSocket() {
    SocketService.onLocationUpdate = (LatLng newLocation, String busId) {
      setState(() {
        _busMarkers[busId] = Marker(
          markerId: MarkerId(busId),
          position: newLocation,
          infoWindow: InfoWindow(title: "Bus $busId (Live)"),
        );
      });

      _mapController?.animateCamera(CameraUpdate.newLatLng(newLocation));
    };

    SocketService.connectToSocket();
  }

  /// Logout Function: Navigates back to Login Page
  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Live Bus Tracking'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: const CameraPosition(
                target: LatLng(22.5726, 88.3639), zoom: 14),
            onMapCreated: (controller) {
              _mapController = controller;
            },
            markers: Set<Marker>.of(_busMarkers.values),
          ),
          if (_isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }
}
