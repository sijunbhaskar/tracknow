import 'package:flutter/material.dart';
import 'route_selection.dart';
import 'passenger_home.dart';
import 'nearby_stops.dart'; // ✅ Import Nearby Bus Stops Page
import 'eta_page.dart'; // ✅ Import ETA Page
import 'alerts_page.dart'; // ✅ Import Alerts Page
import 'route_preview.dart'; // ✅ Import Multi-Stop Route Preview Page
import 'settings.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bus Tracking App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Welcome to Bus Tracker!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            // Route Selection Button ✅ Linked to Route Selection
            _buildFeatureButton(
              context,
              title: 'Search & Select Routes',
              icon: Icons.directions_bus,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const RouteSelection()),
                );
              },
            ),

            // Live Tracking Button ✅ Linked to Passenger Home (Live Tracking)
            _buildFeatureButton(
              context,
              title: 'Live Bus Tracking',
              icon: Icons.map,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const PassengerHome()),
                );
              },
            ),

            // Nearby Stops Button ✅ Linked to NearbyStops Page
            _buildFeatureButton(
              context,
              title: 'Nearby Bus Stops',
              icon: Icons.location_on,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NearbyStops()),
                );
              },
            ),

            // ETA & Bus Status Button ✅ Linked to ETA Page
            _buildFeatureButton(
              context,
              title: 'Estimated Arrival Time (ETA)',
              icon: Icons.access_time,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ETAPage()),
                );
              },
            ),

            // Alerts & Announcements Button ✅ Linked to AlertsPage
            _buildFeatureButton(
              context,
              title: 'Alerts & Announcements',
              icon: Icons.announcement,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AlertsPage()),
                );
              },
            ),

            // Multi-Stop Route Preview Button ✅ Linked to RoutePreview
            _buildFeatureButton(
              context,
              title: 'Multi-Stop Route Preview',
              icon: Icons.route,
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const RoutePreview(
                              routeId: '123', // Replace with actual routeId
                              routeName: 'Main Route',
                            )) // Replace with actual routeName)),
                    );
              },
            ),

            //settings button
            _buildFeatureButton(
              context,
              title: 'settings',
              icon: Icons.settings,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SettingsPage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Helper function to create feature buttons
  Widget _buildFeatureButton(BuildContext context,
      {required String title,
      required IconData icon,
      required VoidCallback onTap}) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(icon, size: 30, color: Colors.blue),
        title: Text(title, style: const TextStyle(fontSize: 18)),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: onTap,
      ),
    );
  }
}
