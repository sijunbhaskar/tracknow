import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class NearbyStops extends StatefulWidget {
  const NearbyStops({super.key});

  @override
  _NearbyStopsState createState() => _NearbyStopsState();
}

class _NearbyStopsState extends State<NearbyStops> {
  GoogleMapController? _mapController;
  List<Map<String, dynamic>> _busStops = [];
  Set<Marker> _markers = {};
  bool _isLoading = true;
  LatLng? _userLocation;

  @override
  void initState() {
    super.initState();
    _fetchUserLocation();
  }

  /// Get the user's current location
  Future<void> _fetchUserLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showError("Location services are disabled.");
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        _showError("Location permissions are denied.");
        return;
      }
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _userLocation = LatLng(position.latitude, position.longitude);
    });

    _fetchNearbyStops(position.latitude, position.longitude);
  }

  /// Fetch nearby stops from the API
  Future<void> _fetchNearbyStops(double lat, double lng) async {
    try {
      final response = await http.get(Uri.parse(
          "http://192.168.43.198:5000/nearby-stops?lat=$lat&lng=$lng"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _busStops = List<Map<String, dynamic>>.from(data['stops']);
          _isLoading = false;

          // Add stops as markers on the map
          _markers = _busStops.map((stop) {
            return Marker(
              markerId: MarkerId(stop['name']),
              position: LatLng(stop['latitude'], stop['longitude']),
              infoWindow: InfoWindow(title: stop['name']),
            );
          }).toSet();
        });
      } else {
        _showError("Failed to load nearby stops.");
      }
    } catch (e) {
      _showError("Error fetching data: $e");
    }
  }

  /// Show error message in Snackbar
  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Nearby Bus Stops")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  flex: 2,
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: _userLocation ?? const LatLng(22.5726, 88.3639),
                      zoom: 14,
                    ),
                    markers: _markers,
                    onMapCreated: (controller) {
                      _mapController = controller;
                    },
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: ListView.builder(
                    itemCount: _busStops.length,
                    itemBuilder: (context, index) {
                      final stop = _busStops[index];
                      return ListTile(
                        leading: const Icon(Icons.directions_bus,
                            color: Colors.blue),
                        title: Text(stop['name']),
                        subtitle: Text(
                            "Lat: ${stop['latitude']}, Lng: ${stop['longitude']}"),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
