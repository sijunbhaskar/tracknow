import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'route_preview.dart'; // ✅ Navigate to Route Preview after selection

class RouteSelection extends StatefulWidget {
  const RouteSelection({super.key});

  @override
  _RouteSelectionState createState() => _RouteSelectionState();
}

class _RouteSelectionState extends State<RouteSelection> {
  List<Map<String, dynamic>> _routes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchRoutes();
  }

  /// Fetch available routes from the backend
  Future<void> _fetchRoutes() async {
    try {
      final response =
          await http.get(Uri.parse("http://192.168.43.198:5000/routes"));
      if (response.statusCode == 200) {
        setState(() {
          _routes = List<Map<String, dynamic>>.from(jsonDecode(response.body));
          _isLoading = false;
        });
      } else {
        _showError("Failed to load routes");
      }
    } catch (e) {
      _showError("Error fetching routes: $e");
    }
  }

  /// Show error message
  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
    setState(() {
      _isLoading = false;
    });
  }

  /// Navigate to Route Preview Page
  void _selectRoute(String routeId, String routeName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            RoutePreview(routeId: routeId, routeName: routeName),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Select a Route")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _routes.length,
              itemBuilder: (context, index) {
                final route = _routes[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    leading:
                        const Icon(Icons.directions_bus, color: Colors.blue),
                    title: Text(route["name"],
                        style: const TextStyle(fontSize: 18)),
                    onTap: () =>
                        _selectRoute(route["id"].toString(), route["name"]),
                  ),
                );
              },
            ),
    );
  }
}
