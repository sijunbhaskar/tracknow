import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RoutePreview extends StatefulWidget {
  final String routeId; // ✅ Accept Route ID
  final String routeName; // ✅ Accept Route Name

  const RoutePreview(
      {super.key, required this.routeId, required this.routeName});

  @override
  _RoutePreviewState createState() => _RoutePreviewState();
}

class _RoutePreviewState extends State<RoutePreview> {
  GoogleMapController? _mapController;
  List<Map<String, dynamic>> _stops = [];
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchStops();
  }

  /// Fetch stops for the selected route
  Future<void> _fetchStops() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.get(Uri.parse(
          "http://192.168.43.198:5000/route-stops?routeId=${widget.routeId}"));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _stops = List<Map<String, dynamic>>.from(data['stops']);
          if (_stops.isNotEmpty) {
            _updateMap();
          }
          _isLoading = false;
        });
      } else {
        _showError("Failed to load stops. Please try again.");
      }
    } catch (e) {
      _showError("Error fetching stops: $e");
    }
  }

  /// Update map with stop markers & route polyline
  void _updateMap() {
    _markers.clear();
    _polylines.clear();

    if (_stops.isNotEmpty) {
      List<LatLng> routePath = [];

      for (var stop in _stops) {
        LatLng stopLocation = LatLng(stop['latitude'], stop['longitude']);
        _markers.add(
          Marker(
            markerId: MarkerId(stop['stop_name']),
            position: stopLocation,
            infoWindow: InfoWindow(title: stop['stop_name']),
          ),
        );
        routePath.add(stopLocation);
      }

      _polylines.add(
        Polyline(
          polylineId: const PolylineId("route_path"),
          points: routePath,
          color: Colors.blue,
          width: 5,
        ),
      );

      if (_mapController != null) {
        _mapController?.animateCamera(CameraUpdate.newLatLngBounds(
          _getBounds(routePath),
          50,
        ));
      }
    }
  }

  /// Get map bounds from stop locations
  LatLngBounds _getBounds(List<LatLng> points) {
    double south = points.first.latitude, north = points.first.latitude;
    double west = points.first.longitude, east = points.first.longitude;

    for (LatLng point in points) {
      if (point.latitude < south) south = point.latitude;
      if (point.latitude > north) north = point.latitude;
      if (point.longitude < west) west = point.longitude;
      if (point.longitude > east) east = point.longitude;
    }
    return LatLngBounds(
        southwest: LatLng(south, west), northeast: LatLng(north, east));
  }

  /// Show error message
  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text(widget.routeName)), // ✅ Show selected route name
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: GoogleMap(
                    initialCameraPosition: const CameraPosition(
                        target: LatLng(22.5726, 88.3639), zoom: 14),
                    onMapCreated: (controller) {
                      _mapController = controller;
                    },
                    markers: _markers,
                    polylines: _polylines,
                  ),
                ),
              ],
            ),
    );
  }
}
